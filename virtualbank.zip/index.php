<?php

require 'core.php';
require 'connect_db.php';
include 'login.inc.php';
?>
